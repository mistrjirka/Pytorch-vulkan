import sys,json,hashlib,math
from pathlib import Path
import torch
backend=sys.argv[1]
if backend=='vulkan':import torch_vulkan as vk
path=Path('/tmp/pv-alpha-original-records.pt');records=torch.load(path,weights_only=True)
gpu=next(r for r in records if r['device'].startswith('vulkan') and r['kwargs'].get('p')==.5)
cpu=next(r for r in records if r['device']=='cpu' and r['kwargs'].get('p')==.5)
assert torch.equal(gpu['input'],cpu['input'])
x=gpu['input'].to(backend).detach().requires_grad_();torch.manual_seed(42)
y=torch.nn.functional.alpha_dropout(x,**gpu['kwargs']);grad=torch.autograd.grad(y.sum(),x)[0]
a=-1.7580993408473766;p=.5;scale=1/math.sqrt((1-p)*(1+p*a*a));offset=-scale*a*p;dropped=scale*a+offset
out=y.detach().cpu();gx=grad.cpu();kept=gpu['input']*scale+offset
is_drop=torch.isclose(out,torch.full_like(out,dropped),rtol=3e-6,atol=3e-6);is_keep=torch.isclose(out,kept,rtol=3e-6,atol=3e-6)
assert bool((is_drop|is_keep).all());torch.testing.assert_close(gx,torch.where(is_drop,0.,scale),rtol=3e-6,atol=3e-6)
result={'backend':backend,'torch':torch.__version__,'torch_git':torch.version.git_version,'fixture_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'original_kwargs':gpu['kwargs'],'input_shape':list(x.shape),'same_seed_output_differences_vs_cpu':int((~torch.isclose(out,cpu['output'],rtol=1e-3,atol=1e-3)).sum()),'affine_output_membership':'passed','mask_gradient_consistency':'passed','upstream_cuda_expected_failure':'common_methods_invocations.py:21751'}
if backend=='vulkan':result['execution_stats']=vk.execution_stats();assert result['execution_stats']['cpu_fallback_calls']==0
print(json.dumps(result),flush=True)
