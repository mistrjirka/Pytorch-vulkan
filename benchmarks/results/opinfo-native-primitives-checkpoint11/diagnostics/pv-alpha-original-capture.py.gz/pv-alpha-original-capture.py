import sys,runpy,torch,json
from pathlib import Path
import torch_vulkan
from torch.testing._internal.common_methods_invocations import op_db
op=next(o for o in op_db if o.name=='nn.functional.alpha_dropout')
original=op.op;records=[]
def traced(input,*args,**kwargs):
 out=original(input,*args,**kwargs)
 records.append({'device':str(input.device),'input':input.detach().cpu().clone(),'output':out.detach().cpu().clone(),'args':args,'kwargs':kwargs})
 torch.save(records,'/tmp/pv-alpha-original-records.pt')
 return out
op.op=traced
sys.argv=['benchmarks/run_upstream_opinfo.py','--worker','--source','/workspace/pytorch-opinfo-5c488690/test/test_ops.py','--out','/workspace/opinfo-alpha-original-capture/rtx','--match','TestCommonPRIVATEUSE1.test_compare_cpu_nn_functional_alpha_dropout_vulkan_float32']
runpy.run_path(sys.argv[0],run_name='__main__')
print('captured',[(r['device'],r['kwargs']) for r in records])
