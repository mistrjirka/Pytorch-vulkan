import sys,hashlib,json,os
from pathlib import Path
import torch
def linear_sum_assignment(cost):
 costs=cost.tolist();dp={0:(0.,[])}
 for row in costs:
  nxt={}
  for mask,(value,order) in dp.items():
   for j,c in enumerate(row):
    if mask&(1<<j):continue
    key=mask|(1<<j);candidate=(value+c,order+[j])
    if key not in nxt or candidate[0]<nxt[key][0]:nxt[key]=candidate
  dp=nxt
 return list(range(len(costs))),dp[(1<<len(costs))-1][1]
backend=sys.argv[1]
if backend=='vulkan':import torch_vulkan as vk
fixture=Path('/tmp/pv-native48-control-input.pt')
if not fixture.exists():
 torch.manual_seed(738)
 torch.save({'eig':torch.randn(2,5,5),'triangular':torch.randn(2,8,8).triu().mT,
             'lu':torch.randn(2,3,3,dtype=torch.complex64)+torch.eye(3)*3,
             'b_left':torch.randn(2,3,4,dtype=torch.complex64),
             'b_right':torch.randn(2,4,3,dtype=torch.complex64)},fixture)
x=torch.load(fixture,weights_only=True)
result={'backend':backend,'torch':torch.__version__,'torch_git':torch.version.git_version,
        'input_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest(),
        'device':vk.device_name() if backend=='vulkan' else torch.cuda.get_device_name(0)}
def error(actual,expected):
 a=actual.detach().cpu();b=expected.detach().cpu();diff=(a-b).abs()
 return {'outside_default_tolerance':int((~torch.isclose(a,b,rtol=1.3e-6,atol=1e-5,equal_nan=True)).sum()),'max_difference':diff.max().item() if diff.numel() else 0}
result['eig']={}
for name in ['eig','triangular']:
 a=x[name];av=a.to(backend);w,v=torch.linalg.eig(av);w,v=w.cpu(),v.cpu();ref=torch.linalg.eigvals(a)
 mismatched=0;largest=0.
 for actual,expected in zip(w,ref):
  i,j=linear_sum_assignment((actual[:,None]-expected[None,:]).abs());delta=(actual[i]-expected[j]).abs();largest=max(largest,delta.max().item());mismatched+=int((~torch.isclose(actual[i],expected[j],rtol=1e-3,atol=1e-3)).sum())
 residual=(a.to(torch.complex64)@v-v*w.unsqueeze(-2)).abs().max().item()
 result['eig'][name]={'multiset_mismatches_at_original_eig_tolerance':mismatched,'max_difference':largest,'max_residual':residual}
 assert mismatched==0 and residual<1e-4

gradients=[]
for dev in ['cpu',backend]:
 a=x['eig'].to(dev).detach().requires_grad_();w,v=torch.linalg.eig(a);loss=w.abs().square().sum()+v.abs().pow(4).sum();gradients.append(torch.autograd.grad(loss,a)[0])
result['eig_gradient']=error(gradients[1],gradients[0]);torch.testing.assert_close(gradients[1].cpu(),gradients[0],rtol=1e-4,atol=1e-4)
result['lu']={}
for left in [False,True]:
 for adjoint in [False,True]:
  a=x['lu'];b=x['b_left' if left else 'b_right'];lu,piv=torch.linalg.lu_factor(a.to(backend));actual=torch.linalg.lu_solve(lu,piv,b.to(backend),left=left,adjoint=adjoint);clu,cpiv=torch.linalg.lu_factor(a);expected=torch.linalg.lu_solve(clu,cpiv,b,left=left,adjoint=adjoint)
  result['lu'][str((left,adjoint))]=error(actual,expected);torch.testing.assert_close(actual.cpu(),expected,rtol=1e-5,atol=1e-5)
result['integer_spatial']={}
for name,fn in [('conv1d',lambda:torch.nn.functional.conv1d(torch.ones(1,2,5,device=backend,dtype=torch.int64),torch.ones(3,2,3,device=backend,dtype=torch.int64))),('conv3d',lambda:torch.nn.functional.conv3d(torch.ones(1,2,5,5,5,device=backend,dtype=torch.int64),torch.ones(3,2,3,3,3,device=backend,dtype=torch.int64))),('avg_pool2d',lambda:torch.nn.functional.avg_pool2d(torch.ones(1,2,5,5,device=backend,dtype=torch.int64),3)),('max_pool2d',lambda:torch.nn.functional.max_pool2d(torch.ones(1,2,5,5,device=backend,dtype=torch.int64),3))]:
 try:y=fn();result['integer_spatial'][name]={'status':'supported','shape':list(y.shape)}
 except Exception as e:result['integer_spatial'][name]={'status':'unsupported','type':type(e).__name__,'message':str(e).splitlines()[0]}
if backend=='vulkan':result['execution_stats']=vk.execution_stats();assert result['execution_stats']['cpu_fallback_calls']==0
print(json.dumps(result,allow_nan=False),flush=True)
