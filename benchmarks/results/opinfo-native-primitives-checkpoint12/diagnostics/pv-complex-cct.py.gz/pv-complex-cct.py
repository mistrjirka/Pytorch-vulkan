import torch, torch_vulkan
from torch.testing._internal.composite_compliance import check_backward_formula,check_forward_ad_formula

def close(a,b,**kw):torch.testing.assert_close(a,b,**kw)
torch.manual_seed(101)
for name,fn,shape in [('eig',torch.linalg.eig,(2,5,5)),('bmm',lambda x:x@x.mH,(2,5,5)),('inv',torch.linalg.inv,(2,5,5)),('abs',torch.abs,(2,5,5)),('mul',lambda x:x*x.conj(),(2,5,5))]:
 dtype=torch.float32 if name=='eig' else torch.complex64
 x=torch.randn(shape,dtype=dtype).to('vulkan').detach().requires_grad_()
 if name=='inv':x=x+torch.eye(5,device='vulkan',dtype=dtype)*4
 for mode in ['back','forward']:
  try:
   if mode=='back':check_backward_formula(fn,(x,),{},output_process_fn_grad=(lambda z:(z[0],z[1].abs())) if name=='eig' else lambda z:z.abs(),assert_equal_fn=close)
   else:check_forward_ad_formula(fn,(x,),{},assert_equal_fn=close)
   print(name,mode,'pass',flush=True)
  except Exception as e:print(name,mode,type(e).__name__,str(e)[:1700],flush=True)
