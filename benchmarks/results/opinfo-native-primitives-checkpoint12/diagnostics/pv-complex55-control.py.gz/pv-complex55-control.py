import sys,json,hashlib
from pathlib import Path
import torch
from torch.utils._pytree import tree_map
which=sys.argv[1]
if which=='vulkan':import torch_vulkan as vk
path=Path('/tmp/pv-complex55-input.pt')
if which=='make':
 torch.manual_seed(759);torch.save({'x':torch.randn(3,5,dtype=torch.complex64),'image':torch.randn(2,3,7,9,dtype=torch.complex64),'grad':torch.randn(1,6,10,dtype=torch.complex64)},path);print(hashlib.sha256(path.read_bytes()).hexdigest());raise SystemExit
inputs=torch.load(path,weights_only=True);records=[]
def values(fn):
 a=fn('cpu');b=fn(which)
 if which=='vulkan':assert vk.execution_stats()['cpu_fallback_calls']==0
 a=tree_map(lambda x:x.detach().cpu(),a);b=tree_map(lambda x:x.detach().cpu(),b)
 torch.testing.assert_close(b,a,rtol=2e-5,atol=2e-5)
def run(name,fn):
 if which=='vulkan':vk.reset_execution_stats()
 try:values(fn);records.append({'name':name,'status':'passed'})
 except Exception as error:
  records.append({'name':name,'status':'error','detail':str(error)})
  if which=='vulkan':raise
for name,fn in [('silu',torch.nn.functional.silu),('exp',torch.exp),('neg',torch.neg)]:
 run(name,lambda d,fn=fn:fn(inputs['x'].to(d).mT))
for exponent in [-3,-.5,0,.5,1,2,3,2+1j]:
 run('power_'+str(exponent),lambda d,e=exponent:inputs['x'].to(d).mT.pow(e))
def gradient(d):
 x=inputs['x'].to(d).detach().requires_grad_();y=x.exp()+x.pow(2)+x*.2j
 return y,torch.autograd.grad(y.abs().square().sum(),x)[0]
run('complex_training',gradient)
def fold(d):
 x=inputs['image'].to(d).mT.detach().requires_grad_();c=torch.nn.functional.unfold(x,3,padding=1,stride=2);o=torch.nn.functional.fold(c,x.shape[-2:],3,padding=1,stride=2)
 return c,o,torch.autograd.grad(o.abs().square().sum(),x)[0]
run('complex_fold_training',fold)
run('overlap_outer_broadcast',lambda d:torch.ops.aten.unfold_backward(inputs['grad'].to(d),[10,20],1,10,2))
result={'device':which,'torch_git':torch.version.git_version,'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'rtol':2e-5,'atol':2e-5,'records':records}
Path('/tmp/pv-complex55-'+which+'.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True)
