import torch,torch_vulkan as vk,json,hashlib
from pathlib import Path
from torch.testing._internal.common_methods_invocations import ops_and_refs
from torch.utils._pytree import tree_map
records=[]
for op in ops_and_refs:
 supported=op.supported_dtypes('vulkan')
 if torch.complex64 not in supported or torch.float32 in supported:continue
 torch.manual_seed(754)
 count=0
 for i,sample in enumerate(op.sample_inputs('cpu',torch.complex64)):
  expected=op(sample.input,*sample.args,**sample.kwargs)
  move=lambda x:x.to('vulkan') if isinstance(x,torch.Tensor) else x
  a,b,c=tree_map(move,(sample.input,sample.args,sample.kwargs))
  vk.reset_execution_stats();actual=op(a,*b,**c);stats=vk.execution_stats();assert stats['cpu_fallback_calls']==0,stats
  actual=tree_map(lambda x:x.detach().cpu() if isinstance(x,torch.Tensor) else x,actual)
  torch.testing.assert_close(actual,expected,rtol=1e-3,atol=1e-3)
  records.append({'operator':op.full_name,'sample_index':i,'fallback_calls_or_attempts':0});count+=1
 print(op.full_name,count,'original complex64 samples pass',flush=True)
Path('/tmp/pv-complex64-only-probe.json').write_text(json.dumps({'torch_git':torch.version.git_version,'mode':'Independent CPU-reference checks of original complex64-only OpInfo samples; not a rewrite of the original upstream run','rtol':1e-3,'atol':1e-3,'records':records},indent=2)+'\n')
