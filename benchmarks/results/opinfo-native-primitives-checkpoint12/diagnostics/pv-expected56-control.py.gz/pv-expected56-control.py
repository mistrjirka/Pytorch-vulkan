import os,sys,hashlib,importlib.util,json,traceback,unittest,collections
from pathlib import Path
which=sys.argv[1];assert which in ['cpu','cuda'];os.environ['PYTORCH_TESTING_DEVICE_ONLY_FOR']=which
import torch
torch.set_num_threads(4)
assert torch.version.git_version=='5c4886908584029761b579af026dcfb627c84070'
source=Path('/workspace/pytorch-opinfo-5c488690/test/test_ops.py');assert hashlib.sha256(source.read_bytes()).hexdigest()=='17ffae61a1654f23d7c2c8f73879bee99c56a80482d061c96975c0fc4720020c'
spec=importlib.util.spec_from_file_location('upstream_test_ops',source);module=importlib.util.module_from_spec(spec);sys.modules[spec.name]=module;spec.loader.exec_module(module)
old=[json.loads(s) for s in Path('/workspace/opinfo-fixes-round16/results.jsonl').read_text().splitlines()];old=[r for r in old if r['status']=='expected_failure'];records=[]
for row in old:
 clsname,name=row['id'].split('.',1);mapped_cls=clsname.replace('PRIVATEUSE1',which.upper()).replace('VULKAN',which.upper());mapped_name=name.replace('_vulkan','_'+which)
 if not hasattr(module,mapped_cls) or not hasattr(getattr(module,mapped_cls),mapped_name):
  records.append({'original_id':row['id'],'control_id':mapped_cls+'.'+mapped_name,'status':'unavailable'});continue
 class Result(unittest.TestResult):
  def __init__(self):super().__init__();self.record={'original_id':row['id'],'control_id':mapped_cls+'.'+mapped_name,'status':'passed','details':[]}
  def mark(self,status,error):self.record['status']=status;self.record['details'].append(''.join(traceback.format_exception(*error))[-16000:] if isinstance(error,tuple) else str(error))
  def addError(self,t,e):self.mark('error',e)
  def addFailure(self,t,e):self.mark('failed',e)
  def addExpectedFailure(self,t,e):self.mark('expected_failure',e)
  def addUnexpectedSuccess(self,t):self.mark('unexpected_success','')
  def addSkip(self,t,e):self.mark('skipped',e)
 result=Result();unittest.TestSuite([getattr(module,mapped_cls)(mapped_name)]).run(result);records.append(result.record);print(row['id'],result.record['status'],flush=True)
result={'device':which,'torch_git':torch.version.git_version,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'mode':'Original upstream expected-failure test IDs mapped to built-in CPU/CUDA; unchanged bodies, samples, skips and tolerances','outcomes':dict(collections.Counter(r['status'] for r in records)),'records':records}
Path('/tmp/pv-expected56-'+which+'.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result['outcomes']),flush=True)
