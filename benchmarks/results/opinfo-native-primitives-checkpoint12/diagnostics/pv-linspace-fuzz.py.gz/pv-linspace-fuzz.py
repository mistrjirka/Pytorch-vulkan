import torch,torch_vulkan as vk,random,json,hashlib
from pathlib import Path
rng=random.Random(751);torch.set_num_threads(4);cases=[]
for dtype,low,high in [(torch.uint8,0,255),(torch.int8,-128,127),(torch.int16,-32768,32767),(torch.int32,-2**31,2**31-1),(torch.int64,-2**63,2**63-1)]:
 for i in range(80):
  a,b=rng.randint(low,high),rng.randint(low,high);n=rng.choice([0,1,2,3,5,8,17,33,127,257])
  if i%4==0 and dtype==torch.int64:
   a=rng.choice([-1,1])*2**rng.randint(24,62);b=max(low,min(high,a+rng.randint(-8192,8192)))
  expected=torch.linspace(a,b,n,dtype=dtype)
  out=torch.empty(n*2+1,dtype=dtype,device='vulkan')[1::2]
  vk.reset_execution_stats();torch.linspace(a,b,n,out=out);stats=vk.execution_stats();assert stats['cpu_fallback_calls']==0 and stats['host_read_max_bytes']==0,stats
  actual=out.cpu();record={'dtype':str(dtype),'start':a,'end':b,'steps':n};cases.append(record)
  try:torch.testing.assert_close(actual,expected,atol=0,rtol=0)
  except Exception:
   torch.save({'case':record,'expected':expected,'actual':actual},'/tmp/pv-linspace-fuzz-failure.pt');raise
Path('/tmp/pv-linspace-fuzz.json').write_text(json.dumps({'seed':751,'cases':len(cases),'exact_comparisons':'passed','numerical_fallback_calls_or_attempts':0,'implicit_host_read_max_bytes':0,'case_parameters_sha256':hashlib.sha256(json.dumps(cases,sort_keys=True).encode()).hexdigest(),'parameters':cases},indent=2)+'\n')
print('400 exact CPU comparisons passed; zero fallback attempts and implicit host reads',flush=True)
