import torch,json,sys,hashlib
from pathlib import Path
which=sys.argv[1]
if which=='vulkan':import torch_vulkan as vk
path=Path('/tmp/pv-power57-input.pt')
if which=='make':
 c=[0.,-0.,1.,-1.,float('inf'),float('-inf'),float('nan')];torch.save(torch.tensor([complex(a,b) for a in c for b in c],dtype=torch.complex64).reshape(7,7).mT,path);raise SystemExit
x=torch.load(path,weights_only=True);records=[]
for e in [-3,-2,-1,-.5,0,.5,1,1.5,2,2.5,3,2+1j,-2+1j,1j]:
 if which=='vulkan':vk.reset_execution_stats()
 try:
  expected=x.pow(e);actual=x.to(which).pow(e)
  if which=='vulkan':assert vk.execution_stats()['cpu_fallback_calls']==0
  torch.testing.assert_close(torch.view_as_real(actual.cpu()),torch.view_as_real(expected),equal_nan=True,rtol=2e-5,atol=2e-5)
  records.append({'exponent':str(e),'status':'passed'})
 except Exception as error:
  records.append({'exponent':str(e),'status':'error','detail':str(error)})
  if which=='vulkan':raise
result={'device':which,'torch_git':torch.version.git_version,'input_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'complex_values':49,'comparison':'CPU FP32 real/imag components independently; equal_nan=True; rtol=atol=2e-5','records':records}
Path('/tmp/pv-power57-'+which+'.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
